package com.londonappbrewery.magiceightball;

import android.app.Application;
import android.test.ApplicationTestCase;

/**
 * <a href="http://d.android.com/tools/testing/testing_android.html">Testing Fundamentals</a>
 */

public class ExampleInstrumentedTest extends ApplicationTestCase<Application> {
    public ExampleInstrumentedTest() {
        super(Application.class);
    }
}
